//
//  PythagorusViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 19.10.2021.
//

import UIKit

class PythagorusViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func GoToBiography(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is BiographyViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
